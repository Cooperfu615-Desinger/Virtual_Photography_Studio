<!-- VPStudio PAGE1 Snapshot: {"version":1,"source":"page1","selection":{"captureMode":"standard","observationCapture":null,"subjectCount":"1","specialSubjectId":"none","characterProfileId":"none","characterCardHairVariantId":"default","characterCardEyewearMode":"default","characterCardWardrobeMode":"full-default","characterCardWardrobeLayerIds":[],"characterCardPromptOverride":"","aspectRatio":"none","mjVersionId":"v8-2","mjAspectRatio":"page1","mjRawMode":"raw","mjStylize":25,"mjChaos":0,"mjWeirdness":0,"mjResolution":"sd","imageTypePresetId":"photorealistic-photo","styleId":"style-none","cameraSystemId":"","sceneAttributeId":"none","locationId":"locations:自然與戶外-nature-outdoors:戶外-向日葵花田:5","importedWorldSceneMode":"none","importedWorldSceneLabel":"","importedWorldSceneArchitectureText":"","zImageVisibleTextEnabled":false,"zImageVisibleTextContent":"","zImageVisibleTextLanguage":"traditional-chinese","zImageVisibleTextPlacement":"background-storefront-sign","fixedCompositionSetId":"none","fixedSetPositionId":"none","fixedSetBackgroundStateId":"none","fixedSetCaptureModeId":"photographer-shot","fixedSetPerformanceStateId":"model-natural","framingId":"camera:景別構圖-framing:全身鏡頭-full-body-shot:8","angleId":"camera:相機視角-angle:全無:0","orbitId":"camera:拍攝方位-orbit-angle:全無:0","lyingCameraId":"none","captureStyleId":"standard","lensId":"camera:鏡頭焦段-focal-length:全無:0","apertureId":"camera:光圈-景深-aperture-depth-of-field:全無:0","shutterId":"camera:快門-動態殘影-shutter-motion-blur:全無:0","opticalEffectId":"camera:光學效果-optical-effects:全無:0","lightingId":"camera:環境光條件-ambient-light-conditions:雪地冷光:17","lightDirectionId":"camera:光線表現-light-style:全無:0","filmId":"camera:底片與相機模擬-camera-film-simulation:全無:0","bodyTypeId":"character:體態-body-type:全無:6","bodyTypeAId":"character:體態-body-type:全無:6","bodyTypeBId":"character:體態-body-type:全無:6","facialFeaturesId":"character:五官特徵-facial-features:全無:0","facialFeaturesAId":"","facialFeaturesBId":"","skinDetailsId":"character:膚質特徵-skin-details:全無:0","skinDetailsAId":"","skinDetailsBId":"","hairstyleId":"character:髮型-hairstyle:全無:0","hairstyleAId":"","hairstyleBId":"","hairStylingStateId":"character:髮絲整理狀態-hair-styling-state:全無:4","hairStylingStateAId":"character:髮絲整理狀態-hair-styling-state:全無:4","hairStylingStateBId":"character:髮絲整理狀態-hair-styling-state:全無:4","hairColorId":"character:髮色-hair-color:全無:0","hairColorAId":"","hairColorBId":"","duoInteractionId":"","duoPoseId":"","duoPoseBaseId":"","duoExpressionId":"","expressionId":"character:表情-facial-expression:溫柔含蓄:7","expressionAId":"","expressionBId":"","poseId":"character:姿勢與肢體語言-pose-body-language:全無:0","specialActionId":"character:特殊動作-special-actions:全無:0","actionPoseCardId":"","poseBaseId":"none","specifiedActionId":"none","specifiedActionSceneRestore":null,"poseOrientationId":"none","poseArrangementId":"none","poseHandId":"none","posePropId":"none","poseHeadId":"none","poseAnchorId":"none","gestureId":"none","propId":"none","headPostureId":"none","gazeId":"none","specialOutfitId":"","specialOutfitAId":"","specialOutfitBId":"","completeLookPaletteId":"none","completeLookPaletteAId":"none","completeLookPaletteBId":"none","outfitPresetId":"","outfitPresetColorId":"","outfitPresetAId":"","outfitPresetAColorId":"","outfitPresetBId":"","outfitPresetBColorId":"","outfitPresetPrimaryColorId":"","outfitPresetContrastColorId":"","outfitPresetLockedPaletteId":"","outfitPresetAPrimaryColorId":"","outfitPresetAContrastColorId":"","outfitPresetALockedPaletteId":"","outfitPresetBPrimaryColorId":"","outfitPresetBContrastColorId":"","outfitPresetBLockedPaletteId":"","topId":"","topAId":"","topBId":"","topFitId":"","topFitAId":"","topFitBId":"","topStylingId":"","topStylingAId":"","topStylingBId":"","topBottomPaletteId":"none","topBottomPaletteAId":"none","topBottomPaletteBId":"none","topColorId":"","topAColorId":"","topBColorId":"","topPatternId":"wardrobe:上身圖案-top-surface-design:全無:0","topAPatternId":"","topBPatternId":"","dressId":"","dressAId":"","dressBId":"","dressColorId":"","dressAColorId":"","dressBColorId":"","pantsId":"","pantsAId":"","pantsBId":"","skirtId":"","skirtAId":"","skirtBId":"","bottomFitId":"","bottomFitAId":"","bottomFitBId":"","bottomRiseId":"","bottomRiseAId":"","bottomRiseBId":"","bottomColorId":"","bottomAColorId":"","bottomBColorId":"","bottomPatternId":"","bottomAPatternId":"","bottomBPatternId":"","outerwearId":"wardrobe:外套-outerwear:全無:0","outerwearFitId":"","outerwearColorId":"","outerwearPatternId":"","outerwearOpeningId":"wardrobe:外套開合-outerwear-opening:全無:4","outerwearStylingId":"","legwearId":"wardrobe:襪類-legwear:全無:0","legwearColorId":"","shoesId":"wardrobe:鞋款-shoes:全無:0","shoesColorId":"","outerwearAId":"","outerwearAFitId":"","outerwearAColorId":"","outerwearAPatternId":"","outerwearAOpeningId":"wardrobe:外套開合-outerwear-opening:全無:4","outerwearAStylingId":"","legwearAId":"","legwearAColorId":"","shoesAId":"","shoesAColorId":"","outerwearBId":"","outerwearBFitId":"","outerwearBColorId":"","outerwearBPatternId":"","outerwearBOpeningId":"wardrobe:外套開合-outerwear-opening:全無:4","outerwearBStylingId":"","legwearBId":"","legwearBColorId":"","shoesBId":"","shoesBColorId":"","headphonesId":"wardrobe:headphones:none","headphonesColorId":"none","faceCoveringId":"wardrobe:faceCovering:none","faceCoveringColorId":"none","headAccessoryId":"wardrobe:頭部配件-head-accessories:全無:0","headAccessoryColorId":"none","eyewearId":"wardrobe:眼鏡-eyewear:全無:0","eyewearColorId":"wardrobe:眼鏡配色-eyewear-color:全無:0","eyewearPlacementId":"wardrobe:眼鏡配戴方式-eyewear-placement:全無:2","earringsId":"wardrobe:耳環-earrings:全無:0","nosePiercingId":"wardrobe:鼻部穿孔-nose-piercings:全無:0","lipPiercingId":"wardrobe:唇部穿孔-lip-piercings:全無:0","neckAccessoryId":"wardrobe:頸部-neck-accessories:全無:0","waistAccessoryId":"wardrobe:腰部配件-waist-accessories:全無:0","headphonesAId":"wardrobe:headphones:none","headphonesAColorId":"none","faceCoveringAId":"wardrobe:faceCovering:none","faceCoveringAColorId":"none","headAccessoryAId":"","headAccessoryAColorId":"none","eyewearAId":"","eyewearAColorId":"","eyewearAPlacementId":"wardrobe:眼鏡配戴方式-eyewear-placement:全無:2","earringsAId":"","neckAccessoryAId":"","waistAccessoryAId":"wardrobe:腰部配件-waist-accessories:全無:0","headphonesBId":"wardrobe:headphones:none","headphonesBColorId":"none","faceCoveringBId":"wardrobe:faceCovering:none","faceCoveringBColorId":"none","headAccessoryBId":"","headAccessoryBColorId":"none","eyewearBId":"","eyewearBColorId":"","eyewearBPlacementId":"wardrobe:眼鏡配戴方式-eyewear-placement:全無:2","earringsBId":"","neckAccessoryBId":"","waistAccessoryBId":"wardrobe:腰部配件-waist-accessories:全無:0"},"outputs":{"grokPrompt":"Image Type:\nCreate a photorealistic editorial portrait.\n\nComposition:\nFull-body portrait.\n\nSubject:\nThe subject is one 20-year-old adult Japanese woman. Gentle demure expression, relaxed brows, softly open eyelids, softly closed lips, relaxed cheeks.\n\nScene:\nThe portrait takes place in sunflower field edge, dense sunflower stems, large yellow flower heads, irregular plant clusters broken by leaves, soil path fragment on one side, rural field background.\n\nLighting:\nCold winter ambience with cool ambient brightness from snow, pale sky where visible.","midjourneyPrompt":"Photorealistic editorial portrait. Full-body portrait. A 20-year-old adult Japanese woman. Gentle demure expression.\n\nSunflower field edge, irregular plant clusters broken by leaves, dense sunflower stems, large yellow flower heads. Snow-bright winter environment, cold pale sky. --v 8.2 --ar 2:3 --raw --s 25 --c 0 --w 0 --sd","zImagePrompt":"Photorealistic editorial portrait.\n\nThe setting is sunflower field edge, dense sunflower stems, large yellow flower heads. Full-body portrait.\n\nA 20-year-old seductive stunning adult Japanese woman, gentle demure expression, relaxed brows, softly open eyelids, softly closed lips, relaxed cheeks.\n\nCold winter ambience with cool ambient brightness from snow, pale sky where visible.","nanoBananaPrompt":"Create a photorealistic editorial portrait. Full-body portrait.\n\nThe subject is one 20-year-old adult Japanese woman. She has a gentle demure expression, relaxed brows, softly open eyelids, softly closed lips, relaxed cheeks.\n\nThe setting is sunflower field edge, dense sunflower stems, large yellow flower heads, irregular plant clusters broken by leaves, soil path fragment on one side, rural field background.\n\nCold winter ambience with cool ambient brightness from snow, pale sky where visible.","extraPrompts":[{"id":"chest-up-portrait","label":"胸上特寫照","text":"Image Type:\nCreate a photorealistic editorial portrait.\n\nComposition:\nVertical portrait composition at a 4:5 aspect ratio, chest-up portrait.\n\nSubject:\nThe subject is one 20-year-old adult Japanese woman. Gentle demure expression, relaxed brows, softly open eyelids, softly closed lips, relaxed cheeks.\n\nScene:\nThe portrait takes place in sunflower field edge, dense sunflower stems, large yellow flower heads, irregular plant clusters broken by leaves, soil path fragment on one side, rural field background.\n\nLighting:\nCold winter ambience with cool ambient brightness from snow, pale sky where visible."},{"id":"full-body-character","label":"全身角色照","text":"Image Type:\nCreate a photorealistic character reference portrait in a single 9:16 vertical image.\n\nSubject:\nThe subject is one 20-year-old adult Japanese woman. Gentle demure expression, relaxed brows, softly open eyelids, softly closed lips, relaxed cheeks.\n\nLighting:\nClean even lighting with clear facial, body, fabric, and footwear readability.\n\nCamera Look:\nFull-body view of the subject standing naturally, centered vertical framing, complete figure visible from head to toe, both hands and both feet completely visible, comfortable space above the hair and below the shoes, natural body proportions, no crop, no hidden limbs, clean realistic character-reference photography, clear facial and garment detail, no visible text."}]},"promptLabels":null} -->
<!-- VPStudio Optional Silence: {"sceneAttributeId":"none","bodyTypeId":"character:體態-body-type:全無:6","bodyTypeAId":"character:體態-body-type:全無:6","bodyTypeBId":"character:體態-body-type:全無:6","hairStylingStateId":"character:髮絲整理狀態-hair-styling-state:全無:4","hairStylingStateAId":"character:髮絲整理狀態-hair-styling-state:全無:4","hairStylingStateBId":"character:髮絲整理狀態-hair-styling-state:全無:4","outerwearOpeningId":"wardrobe:外套開合-outerwear-opening:全無:4","outerwearAOpeningId":"wardrobe:外套開合-outerwear-opening:全無:4","outerwearBOpeningId":"wardrobe:外套開合-outerwear-opening:全無:4","eyewearPlacementId":"wardrobe:眼鏡配戴方式-eyewear-placement:全無:2","eyewearAPlacementId":"wardrobe:眼鏡配戴方式-eyewear-placement:全無:2","eyewearBPlacementId":"wardrobe:眼鏡配戴方式-eyewear-placement:全無:2"} -->
# Generated Prompt - 10/31/2026, 8:00:00 AM
**Source:** Prompt 工作台
**Summary:** 風格：寫實攝影 | 人物：一位性感驚豔的日系或韓系女性 / 溫柔含蓄 | 服裝：- | 場景：戶外：向日葵花田 | 鏡頭：全身鏡頭 (Full Body Shot) | 光影：雪地冷光

## AI Prompt
```text
Photorealistic editorial portrait. Full-body portrait. A 20-year-old adult Japanese woman. Gentle demure expression.

Sunflower field edge, irregular plant clusters broken by leaves, dense sunflower stems, large yellow flower heads. Snow-bright winter environment, cold pale sky. --v 8.2 --ar 2:3 --raw --s 25 --c 0 --w 0 --sd
```

## Gpt
```text
Image Type:
Create a photorealistic editorial portrait.

Composition:
Full-body portrait.

Subject:
The subject is one 20-year-old adult Japanese woman. Gentle demure expression, relaxed brows, softly open eyelids, softly closed lips, relaxed cheeks.

Scene:
The portrait takes place in sunflower field edge, dense sunflower stems, large yellow flower heads, irregular plant clusters broken by leaves, soil path fragment on one side, rural field background.

Lighting:
Cold winter ambience with cool ambient brightness from snow, pale sky where visible.
```

## Z-Image
```text
Photorealistic editorial portrait.

The setting is sunflower field edge, dense sunflower stems, large yellow flower heads. Full-body portrait.

A 20-year-old seductive stunning adult Japanese woman, gentle demure expression, relaxed brows, softly open eyelids, softly closed lips, relaxed cheeks.

Cold winter ambience with cool ambient brightness from snow, pale sky where visible.
```

## Nano Banana 2.1
```text
Create a photorealistic editorial portrait. Full-body portrait.

The subject is one 20-year-old adult Japanese woman. She has a gentle demure expression, relaxed brows, softly open eyelids, softly closed lips, relaxed cheeks.

The setting is sunflower field edge, dense sunflower stems, large yellow flower heads, irregular plant clusters broken by leaves, soil path fragment on one side, rural field background.

Cold winter ambience with cool ambient brightness from snow, pale sky where visible.
```

## 胸上特寫照
```text
Image Type:
Create a photorealistic editorial portrait.

Composition:
Vertical portrait composition at a 4:5 aspect ratio, chest-up portrait.

Subject:
The subject is one 20-year-old adult Japanese woman. Gentle demure expression, relaxed brows, softly open eyelids, softly closed lips, relaxed cheeks.

Scene:
The portrait takes place in sunflower field edge, dense sunflower stems, large yellow flower heads, irregular plant clusters broken by leaves, soil path fragment on one side, rural field background.

Lighting:
Cold winter ambience with cool ambient brightness from snow, pale sky where visible.
```

## 全身角色照
```text
Image Type:
Create a photorealistic character reference portrait in a single 9:16 vertical image.

Subject:
The subject is one 20-year-old adult Japanese woman. Gentle demure expression, relaxed brows, softly open eyelids, softly closed lips, relaxed cheeks.

Lighting:
Clean even lighting with clear facial, body, fabric, and footwear readability.

Camera Look:
Full-body view of the subject standing naturally, centered vertical framing, complete figure visible from head to toe, both hands and both feet completely visible, comfortable space above the hair and below the shoes, natural body proportions, no crop, no hidden limbs, clean realistic character-reference photography, clear facial and garment detail, no visible text.
```

---

## Structured Scheme
* **Style:** Create a photorealistic editorial portrait (寫實攝影), none (全無)
* **Character:** one 20-year-old adult woman (1 位),  (全無),  (全無), none (全無), none (全無), none (全無), none (全無), none (全無), none (全無), none (全無), none (全無), none (全無), none (全無), gentle demure expression, relaxed brows, softly open eyelids, softly closed lips, relaxed cheeks (溫柔含蓄), none (全無),  (全無), none (全無), none (全無), none (全無), none (全無), none (全無), none (全無)
* **Wardrobe:** no nose piercing (全無), no lip piercing (全無), none (全無), none (全無), none (全無), none (全無), none (全無), none (全無), no added top pattern, clean solid-color surface styling (全無), no outerwear, uncluttered silhouette (全無), none (全無), no legwear, bare legs, clean leg styling (全無), no explicit shoe styling, footwear unspecified (全無), none (全無), none (全無),  (全無), none (全無),  (全無), none (全無), no head accessories, clean head styling (全無), none (全無), no eyewear, clean face styling (全無), no specified eyewear frame color (全無), no earrings, clean ear styling (全無), no neck accessories, open neckline styling (全無),  (全無), none (全無),  (全無), none (全無), none (全無), none (全無), no waist accessories, clean waist styling (全無),  (全無), none (全無),  (全無), none (全無), none (全無), none (全無), no waist accessories, clean waist styling (全無), no waist accessories, clean waist styling (全無)
* **Location:**  (全無), none (全無), none (全無), photographer-shot fixed set portrait, subject arranged within the selected set, fixed composition remains readable, face and wardrobe generally clear where framing allows (攝影師拍攝), let the image model choose a natural body attitude and expression that fits the selected fixed set position and capture mode (模型自然發揮), sunflower field edge, dense sunflower stems, large yellow flower heads, irregular plant clusters broken by leaves, soil path fragment on one side, rural field background (戶外：向日葵花田)
* **Framing:** full body shot, head-to-toe figure, environmental scale (全身鏡頭 (Full Body Shot)), none (全無), none (全無), none (全無)
* **Lighting:** snow-bright winter environment, cold pale sky, reflective snowy distance, crisp winter air, cool ambient brightness from snow (雪地冷光), none (全無)
* **Camera & Film:** none (全無), none (全無)
