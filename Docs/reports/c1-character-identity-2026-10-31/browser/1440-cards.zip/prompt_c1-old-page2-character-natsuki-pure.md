# Generated Prompt - 10/31/2026, 8:00:00 AM
**Source:** 角色卡
**Summary:** 角色卡｜18_Natsuki / 保留預設髮型 / 純人物

## AI Prompt
```text
Photorealistic character reference of 18_Natsuki, a 20-year-old adult East Asian woman with a soft compact oval face, gently rounded cheeks, a smooth tapered jaw and a neat rounded chin, large dark brown round-almond eyes with level outer corners and open double eyelids, a small straight nose with a low gentle bridge and neat rounded tip, small soft rose-pink lips with an even lower lip, fair neutral skin with a clean luminous finish, subtle peach eye shading and a light pink cheek flush, petite athletic proportions with balanced shoulders, a narrow waist and toned legs, permanent identity anchors: compact oval face with gently rounded cheeks, large level dark-brown round-almond eyes, small low-bridge nose with a neat rounded tip, small soft rose-pink lips with an even lower lip, short glossy black jaw-length rounded bob with a soft center part, airy separated fringe and polished inward-curved ends, keep the original character hair identity unchanged, pure character identity and hair reference.
```

## GPT Prompt
```text
Image Type:
Create a photorealistic character-card portrait reference.

Subject:
Character Profile Card:
18_Natsuki

A 20-year-old adult East Asian woman.

Facial geometry:
soft compact oval face, gently rounded cheeks, a smooth tapered jaw and a neat rounded chin.

Eye signature:
large dark brown round-almond eyes with level outer corners and open double eyelids.

Nose signature:
small straight nose with a low gentle bridge and a neat rounded tip.

Mouth signature:
small soft rose-pink lips with a shallow cupid bow and an even lower lip.

Skin signature:
fair neutral skin with a clean luminous finish.

Makeup:
subtle peach eye shading with a light pink cheek flush and a soft rose lip finish.

Body:
petite athletic proportions with balanced shoulders, a narrow waist and toned legs.

Permanent identity anchors:
compact oval face with gently rounded cheeks, large level dark-brown round-almond eyes, small low-bridge nose with a neat rounded tip, small soft rose-pink lips with an even lower lip.

Hair:
short glossy black jaw-length rounded bob with a soft center part, airy separated fringe and polished inward-curved ends, keep the original character hair identity unchanged.

Photographic direction:
photorealistic editorial portrait, clean locker-room sports editorial photographic realism, coherent facial identity, realistic technical jersey and athletic trim construction.

Camera Look:
clean realistic character reference, neutral production-ready detail, consistent identity, realistic facial proportions
```

## Z-Image Prompt
```text
Natural photorealistic character reference of 18_Natsuki, a 20-year-old adult East Asian woman, compact oval face with gently rounded cheeks, large level dark-brown round-almond eyes, small low-bridge nose with a neat rounded tip, small soft rose-pink lips with an even lower lip, fair neutral skin with a clean luminous finish, petite athletic proportions with balanced shoulders, a narrow waist and toned legs, short glossy black jaw-length rounded bob with a soft center part, airy separated fringe and polished inward-curved ends, keep the original character hair identity unchanged, photorealistic editorial portrait, clean locker-room sports editorial photographic realism, coherent facial identity, realistic technical jersey and athletic trim construction.
```

## Headshot Prompt
```text
headshot reference of 18_Natsuki, tight face-and-hair portrait, neutral clean background, consistent facial identity, a 20-year-old adult East Asian woman with a soft compact oval face, gently rounded cheeks, a smooth tapered jaw and a neat rounded chin, large dark brown round-almond eyes with level outer corners and open double eyelids, a small straight nose with a low gentle bridge and neat rounded tip, small soft rose-pink lips with an even lower lip, fair neutral skin with a clean luminous finish, subtle peach eye shading and a light pink cheek flush, petite athletic proportions with balanced shoulders, a narrow waist and toned legs, permanent identity anchors: compact oval face with gently rounded cheeks, large level dark-brown round-almond eyes, small low-bridge nose with a neat rounded tip, small soft rose-pink lips with an even lower lip, short glossy black jaw-length rounded bob with a soft center part, airy separated fringe and polished inward-curved ends, keep the original character hair identity unchanged, clear skin texture, makeup, eyes, nose, lips, jawline, and hairline.
```

## Four-View Prompt
```text
four-view character reference sheet for 18_Natsuki, one image containing front view, left 45-degree view, side profile view, and back view, same exact woman in every panel, matched facial proportions, consistent hair silhouette, a 20-year-old adult East Asian woman with a soft compact oval face, gently rounded cheeks, a smooth tapered jaw and a neat rounded chin, large dark brown round-almond eyes with level outer corners and open double eyelids, a small straight nose with a low gentle bridge and neat rounded tip, small soft rose-pink lips with an even lower lip, fair neutral skin with a clean luminous finish, subtle peach eye shading and a light pink cheek flush, petite athletic proportions with balanced shoulders, a narrow waist and toned legs, permanent identity anchors: compact oval face with gently rounded cheeks, large level dark-brown round-almond eyes, small low-bridge nose with a neat rounded tip, small soft rose-pink lips with an even lower lip, short glossy black jaw-length rounded bob with a soft center part, airy separated fringe and polished inward-curved ends, keep the original character hair identity unchanged, no clothing design emphasis, neutral shoulders and body reference.
```

## Full-Body Reference Prompt
```text
full-body character reference of 18_Natsuki, neutral studio reference, clear standing full-body view, same exact identity, a 20-year-old adult East Asian woman with a soft compact oval face, gently rounded cheeks, a smooth tapered jaw and a neat rounded chin, large dark brown round-almond eyes with level outer corners and open double eyelids, a small straight nose with a low gentle bridge and neat rounded tip, small soft rose-pink lips with an even lower lip, fair neutral skin with a clean luminous finish, subtle peach eye shading and a light pink cheek flush, petite athletic proportions with balanced shoulders, a narrow waist and toned legs, permanent identity anchors: compact oval face with gently rounded cheeks, large level dark-brown round-almond eyes, small low-bridge nose with a neat rounded tip, small soft rose-pink lips with an even lower lip, short glossy black jaw-length rounded bob with a soft center part, airy separated fringe and polished inward-curved ends, keep the original character hair identity unchanged, pure body and hair reference without fixed outfit design.
```

---

## Structured Scheme

