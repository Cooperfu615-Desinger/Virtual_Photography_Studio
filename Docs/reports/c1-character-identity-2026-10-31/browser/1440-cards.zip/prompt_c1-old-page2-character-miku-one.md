# Generated Prompt - 10/31/2026, 8:00:00 AM
**Source:** 角色卡
**Summary:** 角色卡｜36_Miku / 保留預設髮型 / 上身

## AI Prompt
```text
Photorealistic character reference of 36_Miku, a 20-year-old adult East Asian woman with a compact soft oval face, gently rounded cheeks, a narrow smooth jaw and a neat rounded chin, large dark brown round-almond eyes set slightly wide with level outer corners, open double eyelids and soft lower-lid fullness, a small straight nose with a low gentle bridge and a tidy rounded tip, small rose-red lips with a shallow cupid bow and a fuller lower lip, fair neutral skin with a clean luminous finish, fine brown-black upper-lash definition and restrained pink cheek color, petite balanced proportions with narrow shoulders, a defined waist and softly toned legs, permanent identity anchors: compact soft oval face with rounded cheeks, large wide-set dark-brown round-almond eyes, small low-bridge rounded-tip nose, small rose-red lips with a fuller lower lip, long natural black hair gathered into a high braided looped bun with curled ribbon-like loops, airy eyebrow-skimming bangs and long curled face-framing tendrils, keep the original character hair identity unchanged, wearing navy oversized V-neck cardigan over a crisp white collared shirt.
```

## GPT Prompt
```text
Image Type:
Create a photorealistic character-card portrait reference.

Subject:
Character Profile Card:
36_Miku

A 20-year-old adult East Asian woman.

Facial geometry:
compact soft oval face, gently rounded cheeks, a narrow smooth jaw and a neat rounded chin.

Eye signature:
large dark brown round-almond eyes set slightly wide with level outer corners, open double eyelids and soft lower-lid fullness.

Nose signature:
small straight nose with a low gentle bridge and a tidy rounded tip.

Mouth signature:
small rose-red lips with a shallow cupid bow and a fuller lower lip.

Skin signature:
fair neutral skin with a clean luminous finish.

Makeup:
fine brown-black upper-lash definition with restrained pink cheek color and a rose-red lip finish.

Body:
petite balanced proportions with narrow shoulders, a defined waist and softly toned legs.

Permanent identity anchors:
compact soft oval face with rounded cheeks, large wide-set dark-brown round-almond eyes, small low-bridge rounded-tip nose, small rose-red lips with a fuller lower lip.

Hair:
long natural black hair gathered into a high braided looped bun with curled ribbon-like loops, airy eyebrow-skimming bangs and long curled face-framing tendrils, keep the original character hair identity unchanged.

Photographic direction:
photorealistic editorial portrait, bright commuter-train photographic realism, coherent facial identity, realistic knitwear, cotton shirting, pleated fabric and leather construction.

Wardrobe layers:
上身: navy oversized V-neck cardigan over a crisp white collared shirt

Camera Look:
clean realistic character reference, neutral production-ready detail, consistent identity, realistic facial proportions
```

## Z-Image Prompt
```text
Natural photorealistic character reference of 36_Miku, a 20-year-old adult East Asian woman, compact soft oval face with rounded cheeks, large wide-set dark-brown round-almond eyes, small low-bridge rounded-tip nose, small rose-red lips with a fuller lower lip, fair neutral skin with a clean luminous finish, petite balanced proportions with narrow shoulders, a defined waist and softly toned legs, long natural black hair gathered into a high braided looped bun with curled ribbon-like loops, airy eyebrow-skimming bangs and long curled face-framing tendrils, keep the original character hair identity unchanged, wearing navy oversized V-neck cardigan over a crisp white collared shirt, photorealistic editorial portrait, bright commuter-train photographic realism, coherent facial identity, realistic knitwear, cotton shirting, pleated fabric and leather construction.
```

## Headshot Prompt
```text
headshot reference of 36_Miku, tight face-and-hair portrait, neutral clean background, consistent facial identity, a 20-year-old adult East Asian woman with a compact soft oval face, gently rounded cheeks, a narrow smooth jaw and a neat rounded chin, large dark brown round-almond eyes set slightly wide with level outer corners, open double eyelids and soft lower-lid fullness, a small straight nose with a low gentle bridge and a tidy rounded tip, small rose-red lips with a shallow cupid bow and a fuller lower lip, fair neutral skin with a clean luminous finish, fine brown-black upper-lash definition and restrained pink cheek color, petite balanced proportions with narrow shoulders, a defined waist and softly toned legs, permanent identity anchors: compact soft oval face with rounded cheeks, large wide-set dark-brown round-almond eyes, small low-bridge rounded-tip nose, small rose-red lips with a fuller lower lip, long natural black hair gathered into a high braided looped bun with curled ribbon-like loops, airy eyebrow-skimming bangs and long curled face-framing tendrils, keep the original character hair identity unchanged, clear skin texture, makeup, eyes, nose, lips, jawline, and hairline.
```

## Four-View Prompt
```text
four-view character reference sheet for 36_Miku, one image containing front view, left 45-degree view, side profile view, and back view, same exact woman in every panel, matched facial proportions, consistent hair silhouette, a 20-year-old adult East Asian woman with a compact soft oval face, gently rounded cheeks, a narrow smooth jaw and a neat rounded chin, large dark brown round-almond eyes set slightly wide with level outer corners, open double eyelids and soft lower-lid fullness, a small straight nose with a low gentle bridge and a tidy rounded tip, small rose-red lips with a shallow cupid bow and a fuller lower lip, fair neutral skin with a clean luminous finish, fine brown-black upper-lash definition and restrained pink cheek color, petite balanced proportions with narrow shoulders, a defined waist and softly toned legs, permanent identity anchors: compact soft oval face with rounded cheeks, large wide-set dark-brown round-almond eyes, small low-bridge rounded-tip nose, small rose-red lips with a fuller lower lip, long natural black hair gathered into a high braided looped bun with curled ribbon-like loops, airy eyebrow-skimming bangs and long curled face-framing tendrils, keep the original character hair identity unchanged, use the included wardrobe layers consistently: navy oversized V-neck cardigan over a crisp white collared shirt.
```

## Full-Body Reference Prompt
```text
full-body character reference of 36_Miku, neutral studio reference, clear standing full-body view, same exact identity, a 20-year-old adult East Asian woman with a compact soft oval face, gently rounded cheeks, a narrow smooth jaw and a neat rounded chin, large dark brown round-almond eyes set slightly wide with level outer corners, open double eyelids and soft lower-lid fullness, a small straight nose with a low gentle bridge and a tidy rounded tip, small rose-red lips with a shallow cupid bow and a fuller lower lip, fair neutral skin with a clean luminous finish, fine brown-black upper-lash definition and restrained pink cheek color, petite balanced proportions with narrow shoulders, a defined waist and softly toned legs, permanent identity anchors: compact soft oval face with rounded cheeks, large wide-set dark-brown round-almond eyes, small low-bridge rounded-tip nose, small rose-red lips with a fuller lower lip, long natural black hair gathered into a high braided looped bun with curled ribbon-like loops, airy eyebrow-skimming bangs and long curled face-framing tendrils, keep the original character hair identity unchanged, included wardrobe layers: navy oversized V-neck cardigan over a crisp white collared shirt.
```

---

## Structured Scheme

