<!-- VPStudio PAGE1 Snapshot: {"version":1,"source":"page1","selection":{"captureMode":"standard","observationCapture":null,"subjectCount":"1","specialSubjectId":"none","characterProfileId":"character-natsuki","characterCardHairVariantId":"default","characterCardEyewearMode":"default","characterCardWardrobeMode":"selected-layers","characterCardWardrobeLayerIds":[],"characterCardPromptOverride":"","aspectRatio":"none","mjVersionId":"v8-2","mjAspectRatio":"page1","mjRawMode":"raw","mjStylize":25,"mjChaos":0,"mjWeirdness":0,"mjResolution":"sd","imageTypePresetId":"photorealistic-photo","styleId":"style-none","cameraSystemId":"","sceneAttributeId":"none","locationId":"locations:攝影棚與背景-studio-sets:全無:0","importedWorldSceneMode":"none","importedWorldSceneLabel":"","importedWorldSceneArchitectureText":"","zImageVisibleTextEnabled":false,"zImageVisibleTextContent":"","zImageVisibleTextLanguage":"traditional-chinese","zImageVisibleTextPlacement":"background-storefront-sign","fixedCompositionSetId":"none","fixedSetPositionId":"none","fixedSetBackgroundStateId":"none","fixedSetCaptureModeId":"photographer-shot","fixedSetPerformanceStateId":"model-natural","framingId":"camera:景別構圖-framing:全無:0","angleId":"camera:相機視角-angle:全無:0","orbitId":"camera:拍攝方位-orbit-angle:全無:0","lyingCameraId":"none","captureStyleId":"standard","lensId":"camera:鏡頭焦段-focal-length:全無:0","apertureId":"camera:光圈-景深-aperture-depth-of-field:全無:0","shutterId":"camera:快門-動態殘影-shutter-motion-blur:全無:0","opticalEffectId":"camera:光學效果-optical-effects:全無:0","lightingId":"camera:環境光條件-ambient-light-conditions:全無:0","lightDirectionId":"camera:光線表現-light-style:全無:0","filmId":"camera:底片與相機模擬-camera-film-simulation:全無:0","bodyTypeId":"character:體態-body-type:全無:6","bodyTypeAId":"character:體態-body-type:全無:6","bodyTypeBId":"character:體態-body-type:全無:6","facialFeaturesId":"","facialFeaturesAId":"","facialFeaturesBId":"","skinDetailsId":"","skinDetailsAId":"","skinDetailsBId":"","hairstyleId":"","hairstyleAId":"","hairstyleBId":"","hairStylingStateId":"character:髮絲整理狀態-hair-styling-state:全無:4","hairStylingStateAId":"character:髮絲整理狀態-hair-styling-state:全無:4","hairStylingStateBId":"character:髮絲整理狀態-hair-styling-state:全無:4","hairColorId":"","hairColorAId":"","hairColorBId":"","duoInteractionId":"","duoPoseId":"","duoPoseBaseId":"","duoExpressionId":"","expressionId":"","expressionAId":"","expressionBId":"","poseId":"","specialActionId":"","actionPoseCardId":"","poseBaseId":"none","specifiedActionId":"none","specifiedActionSceneRestore":null,"poseOrientationId":"none","poseArrangementId":"none","poseHandId":"none","posePropId":"none","poseHeadId":"none","poseAnchorId":"none","gestureId":"none","propId":"none","headPostureId":"none","gazeId":"none","specialOutfitId":"","specialOutfitAId":"","specialOutfitBId":"","completeLookPaletteId":"none","completeLookPaletteAId":"none","completeLookPaletteBId":"none","outfitPresetId":"","outfitPresetColorId":"","outfitPresetAId":"","outfitPresetAColorId":"","outfitPresetBId":"","outfitPresetBColorId":"","outfitPresetPrimaryColorId":"","outfitPresetContrastColorId":"","outfitPresetLockedPaletteId":"","outfitPresetAPrimaryColorId":"","outfitPresetAContrastColorId":"","outfitPresetALockedPaletteId":"","outfitPresetBPrimaryColorId":"","outfitPresetBContrastColorId":"","outfitPresetBLockedPaletteId":"","topId":"","topAId":"","topBId":"","topFitId":"","topFitAId":"","topFitBId":"","topStylingId":"","topStylingAId":"","topStylingBId":"","topBottomPaletteId":"none","topBottomPaletteAId":"none","topBottomPaletteBId":"none","topColorId":"","topAColorId":"","topBColorId":"","topPatternId":"wardrobe:上身圖案-top-surface-design:全無:0","topAPatternId":"","topBPatternId":"","dressId":"","dressAId":"","dressBId":"","dressColorId":"","dressAColorId":"","dressBColorId":"","pantsId":"","pantsAId":"","pantsBId":"","skirtId":"","skirtAId":"","skirtBId":"","bottomFitId":"","bottomFitAId":"","bottomFitBId":"","bottomRiseId":"","bottomRiseAId":"","bottomRiseBId":"","bottomColorId":"","bottomAColorId":"","bottomBColorId":"","bottomPatternId":"","bottomAPatternId":"","bottomBPatternId":"","outerwearId":"wardrobe:外套-outerwear:全無:0","outerwearFitId":"","outerwearColorId":"","outerwearPatternId":"","outerwearOpeningId":"wardrobe:外套開合-outerwear-opening:全無:4","outerwearStylingId":"","legwearId":"wardrobe:襪類-legwear:全無:0","legwearColorId":"","shoesId":"wardrobe:鞋款-shoes:全無:0","shoesColorId":"","outerwearAId":"","outerwearAFitId":"","outerwearAColorId":"","outerwearAPatternId":"","outerwearAOpeningId":"wardrobe:外套開合-outerwear-opening:全無:4","outerwearAStylingId":"","legwearAId":"","legwearAColorId":"","shoesAId":"","shoesAColorId":"","outerwearBId":"","outerwearBFitId":"","outerwearBColorId":"","outerwearBPatternId":"","outerwearBOpeningId":"wardrobe:外套開合-outerwear-opening:全無:4","outerwearBStylingId":"","legwearBId":"","legwearBColorId":"","shoesBId":"","shoesBColorId":"","headphonesId":"wardrobe:headphones:none","headphonesColorId":"none","faceCoveringId":"wardrobe:faceCovering:none","faceCoveringColorId":"none","headAccessoryId":"wardrobe:頭部配件-head-accessories:全無:0","headAccessoryColorId":"none","eyewearId":"wardrobe:眼鏡-eyewear:全無:0","eyewearColorId":"wardrobe:眼鏡配色-eyewear-color:全無:0","eyewearPlacementId":"wardrobe:眼鏡配戴方式-eyewear-placement:全無:2","earringsId":"wardrobe:耳環-earrings:全無:0","nosePiercingId":"wardrobe:鼻部穿孔-nose-piercings:全無:0","lipPiercingId":"wardrobe:唇部穿孔-lip-piercings:全無:0","neckAccessoryId":"wardrobe:頸部-neck-accessories:全無:0","waistAccessoryId":"wardrobe:腰部配件-waist-accessories:全無:0","headphonesAId":"wardrobe:headphones:none","headphonesAColorId":"none","faceCoveringAId":"wardrobe:faceCovering:none","faceCoveringAColorId":"none","headAccessoryAId":"","headAccessoryAColorId":"none","eyewearAId":"","eyewearAColorId":"","eyewearAPlacementId":"wardrobe:眼鏡配戴方式-eyewear-placement:全無:2","earringsAId":"","neckAccessoryAId":"","waistAccessoryAId":"wardrobe:腰部配件-waist-accessories:全無:0","headphonesBId":"wardrobe:headphones:none","headphonesBColorId":"none","faceCoveringBId":"wardrobe:faceCovering:none","faceCoveringBColorId":"none","headAccessoryBId":"","headAccessoryBColorId":"none","eyewearBId":"","eyewearBColorId":"","eyewearBPlacementId":"wardrobe:眼鏡配戴方式-eyewear-placement:全無:2","earringsBId":"","neckAccessoryBId":"","waistAccessoryBId":"wardrobe:腰部配件-waist-accessories:全無:0"},"outputs":{"grokPrompt":"Image Type:\nCreate a photorealistic editorial portrait.\n\nSubject:\nCharacter Profile Card:\n18_Natsuki.\n\nA 20-year-old adult East Asian woman.\n\nFacial geometry:\nSoft compact oval face, gently rounded cheeks, a smooth tapered jaw and a neat rounded chin.\n\nEye signature:\nLarge dark brown round-almond eyes with level outer corners and open double eyelids.\n\nNose signature:\nSmall straight nose with a low gentle bridge and a neat rounded tip.\n\nMouth signature:\nSmall soft rose-pink lips with a shallow cupid bow and an even lower lip.\n\nSkin signature:\nFair neutral skin with a clean luminous finish.\n\nMakeup:\nSubtle peach eye shading with a light pink cheek flush and a soft rose lip finish.\n\nBody:\nPetite athletic proportions with balanced shoulders, a narrow waist and toned legs.\n\nPermanent identity anchors:\nCompact oval face with gently rounded cheeks, large level dark-brown round-almond eyes, small low-bridge nose with a neat rounded tip, small soft rose-pink lips with an even lower lip.\n\nHair:\nShort glossy black jaw-length rounded bob with a soft center part, airy separated fringe and polished inward-curved ends.\n\nPhotographic direction:\nPhotorealistic editorial portrait, clean sports editorial photographic realism, coherent facial identity, realistic technical jersey and athletic trim construction.","midjourneyPrompt":"Photorealistic editorial portrait. A 20-year-old adult East Asian woman, compact oval face with gently rounded cheeks, large level dark-brown round-almond eyes, small low-bridge nose with a neat rounded tip, small soft rose-pink lips with an even lower lip, fair neutral skin with a clean luminous finish, subtle peach eye shading with a light pink cheek flush and a soft rose lip finish, short glossy black jaw-length rounded bob with a soft center part, airy separated fringe and polished inward-curved ends. --v 8.2 --ar 2:3 --raw --s 25 --c 0 --w 0 --sd","zImagePrompt":"Photorealistic editorial portrait.\n\nA 20-year-old adult East Asian woman, compact oval face with gently rounded cheeks, large level dark-brown round-almond eyes, small low-bridge nose with a neat rounded tip, small soft rose-pink lips with an even lower lip, fair neutral skin with a clean luminous finish, petite athletic proportions with balanced shoulders, a narrow waist and toned legs, short glossy black jaw-length rounded bob with a soft center part, airy separated fringe and polished inward-curved ends.","nanoBananaPrompt":"Create a photorealistic editorial portrait.\n\nThe subject is a 20-year-old adult East Asian woman. She has a soft compact oval face, gently rounded cheeks, a smooth tapered jaw and a neat rounded chin. Her eyes are large dark brown round-almond eyes with level outer corners and open double eyelids. She has a small straight nose with a low gentle bridge and a neat rounded tip. Her lips are small soft rose-pink lips with a shallow cupid bow and an even lower lip. Her complexion shows fair neutral skin with a clean luminous finish. Her makeup uses subtle peach eye shading with a light pink cheek flush and a soft rose lip finish. Her figure has petite athletic proportions with balanced shoulders, a narrow waist and toned legs. Her defining features are compact oval face with gently rounded cheeks, large level dark-brown round-almond eyes, small low-bridge nose with a neat rounded tip, small soft rose-pink lips with an even lower lip. Her hair is short glossy black jaw-length rounded bob with a soft center part, airy separated fringe and polished inward-curved ends. Photorealistic editorial portrait, clean sports editorial photographic realism, coherent facial identity, realistic technical jersey and athletic trim construction.","extraPrompts":[{"id":"chest-up-portrait","label":"胸上特寫照","text":"Image Type:\nCreate a photorealistic editorial portrait.\n\nComposition:\nVertical portrait composition at a 4:5 aspect ratio, chest-up portrait.\n\nSubject:\nCharacter Profile Card:\n18_Natsuki.\n\nA 20-year-old adult East Asian woman.\n\nFacial geometry:\nSoft compact oval face, gently rounded cheeks, a smooth tapered jaw and a neat rounded chin.\n\nEye signature:\nLarge dark brown round-almond eyes with level outer corners and open double eyelids.\n\nNose signature:\nSmall straight nose with a low gentle bridge and a neat rounded tip.\n\nMouth signature:\nSmall soft rose-pink lips with a shallow cupid bow and an even lower lip.\n\nSkin signature:\nFair neutral skin with a clean luminous finish.\n\nMakeup:\nSubtle peach eye shading with a light pink cheek flush and a soft rose lip finish.\n\nBody:\nBalanced shoulders.\n\nPermanent identity anchors:\nCompact oval face with gently rounded cheeks, large level dark-brown round-almond eyes, small low-bridge nose with a neat rounded tip, small soft rose-pink lips with an even lower lip.\n\nHair:\nShort glossy black jaw-length rounded bob with a soft center part, airy separated fringe and polished inward-curved ends.\n\nPhotographic direction:\nPhotorealistic editorial portrait, clean sports editorial photographic realism, coherent facial identity, realistic technical jersey and athletic trim construction."},{"id":"full-body-character","label":"全身角色照","text":"Image Type:\nCreate a photorealistic character reference portrait in a single 9:16 vertical image.\n\nSubject:\nCharacter Profile Card:\n18_Natsuki.\n\nA 20-year-old adult East Asian woman.\n\nFacial geometry:\nSoft compact oval face, gently rounded cheeks, a smooth tapered jaw and a neat rounded chin.\n\nEye signature:\nLarge dark brown round-almond eyes with level outer corners and open double eyelids.\n\nNose signature:\nSmall straight nose with a low gentle bridge and a neat rounded tip.\n\nMouth signature:\nSmall soft rose-pink lips with a shallow cupid bow and an even lower lip.\n\nSkin signature:\nFair neutral skin with a clean luminous finish.\n\nMakeup:\nSubtle peach eye shading with a light pink cheek flush and a soft rose lip finish.\n\nBody:\nPetite athletic proportions with balanced shoulders, a narrow waist and toned legs.\n\nPermanent identity anchors:\nCompact oval face with gently rounded cheeks, large level dark-brown round-almond eyes, small low-bridge nose with a neat rounded tip, small soft rose-pink lips with an even lower lip.\n\nHair:\nShort glossy black jaw-length rounded bob with a soft center part, airy separated fringe and polished inward-curved ends.\n\nLighting:\nClean even lighting with clear facial, body, fabric, and footwear readability.\n\nCamera Look:\nFull-body view of the subject standing naturally, centered vertical framing, complete figure visible from head to toe, both hands and both feet completely visible, comfortable space above the hair and below the shoes, natural body proportions, no crop, no hidden limbs, clean realistic character-reference photography, clear facial and garment detail, no visible text."}]},"promptLabels":null} -->
<!-- VPStudio Optional Silence: {"sceneAttributeId":"none","bodyTypeId":"character:體態-body-type:全無:6","bodyTypeAId":"character:體態-body-type:全無:6","bodyTypeBId":"character:體態-body-type:全無:6","hairStylingStateId":"character:髮絲整理狀態-hair-styling-state:全無:4","hairStylingStateAId":"character:髮絲整理狀態-hair-styling-state:全無:4","hairStylingStateBId":"character:髮絲整理狀態-hair-styling-state:全無:4","outerwearOpeningId":"wardrobe:外套開合-outerwear-opening:全無:4","outerwearAOpeningId":"wardrobe:外套開合-outerwear-opening:全無:4","outerwearBOpeningId":"wardrobe:外套開合-outerwear-opening:全無:4","eyewearPlacementId":"wardrobe:眼鏡配戴方式-eyewear-placement:全無:2","eyewearAPlacementId":"wardrobe:眼鏡配戴方式-eyewear-placement:全無:2","eyewearBPlacementId":"wardrobe:眼鏡配戴方式-eyewear-placement:全無:2"} -->
# Generated Prompt - 10/31/2026, 8:00:00 AM
**Source:** Prompt 工作台
**Summary:** 風格：寫實攝影 | 人物：18_Natsuki / 18_Natsuki 角色卡 | 服裝：- | 場景：- | 鏡頭：- | 光影：-

## AI Prompt
```text
Photorealistic editorial portrait. A 20-year-old adult East Asian woman, compact oval face with gently rounded cheeks, large level dark-brown round-almond eyes, small low-bridge nose with a neat rounded tip, small soft rose-pink lips with an even lower lip, fair neutral skin with a clean luminous finish, subtle peach eye shading with a light pink cheek flush and a soft rose lip finish, short glossy black jaw-length rounded bob with a soft center part, airy separated fringe and polished inward-curved ends. --v 8.2 --ar 2:3 --raw --s 25 --c 0 --w 0 --sd
```

## Gpt
```text
Image Type:
Create a photorealistic editorial portrait.

Subject:
Character Profile Card:
18_Natsuki.

A 20-year-old adult East Asian woman.

Facial geometry:
Soft compact oval face, gently rounded cheeks, a smooth tapered jaw and a neat rounded chin.

Eye signature:
Large dark brown round-almond eyes with level outer corners and open double eyelids.

Nose signature:
Small straight nose with a low gentle bridge and a neat rounded tip.

Mouth signature:
Small soft rose-pink lips with a shallow cupid bow and an even lower lip.

Skin signature:
Fair neutral skin with a clean luminous finish.

Makeup:
Subtle peach eye shading with a light pink cheek flush and a soft rose lip finish.

Body:
Petite athletic proportions with balanced shoulders, a narrow waist and toned legs.

Permanent identity anchors:
Compact oval face with gently rounded cheeks, large level dark-brown round-almond eyes, small low-bridge nose with a neat rounded tip, small soft rose-pink lips with an even lower lip.

Hair:
Short glossy black jaw-length rounded bob with a soft center part, airy separated fringe and polished inward-curved ends.

Photographic direction:
Photorealistic editorial portrait, clean sports editorial photographic realism, coherent facial identity, realistic technical jersey and athletic trim construction.
```

## Z-Image
```text
Photorealistic editorial portrait.

A 20-year-old adult East Asian woman, compact oval face with gently rounded cheeks, large level dark-brown round-almond eyes, small low-bridge nose with a neat rounded tip, small soft rose-pink lips with an even lower lip, fair neutral skin with a clean luminous finish, petite athletic proportions with balanced shoulders, a narrow waist and toned legs, short glossy black jaw-length rounded bob with a soft center part, airy separated fringe and polished inward-curved ends.
```

## Nano Banana 2.1
```text
Create a photorealistic editorial portrait.

The subject is a 20-year-old adult East Asian woman. She has a soft compact oval face, gently rounded cheeks, a smooth tapered jaw and a neat rounded chin. Her eyes are large dark brown round-almond eyes with level outer corners and open double eyelids. She has a small straight nose with a low gentle bridge and a neat rounded tip. Her lips are small soft rose-pink lips with a shallow cupid bow and an even lower lip. Her complexion shows fair neutral skin with a clean luminous finish. Her makeup uses subtle peach eye shading with a light pink cheek flush and a soft rose lip finish. Her figure has petite athletic proportions with balanced shoulders, a narrow waist and toned legs. Her defining features are compact oval face with gently rounded cheeks, large level dark-brown round-almond eyes, small low-bridge nose with a neat rounded tip, small soft rose-pink lips with an even lower lip. Her hair is short glossy black jaw-length rounded bob with a soft center part, airy separated fringe and polished inward-curved ends. Photorealistic editorial portrait, clean sports editorial photographic realism, coherent facial identity, realistic technical jersey and athletic trim construction.
```

## 胸上特寫照
```text
Image Type:
Create a photorealistic editorial portrait.

Composition:
Vertical portrait composition at a 4:5 aspect ratio, chest-up portrait.

Subject:
Character Profile Card:
18_Natsuki.

A 20-year-old adult East Asian woman.

Facial geometry:
Soft compact oval face, gently rounded cheeks, a smooth tapered jaw and a neat rounded chin.

Eye signature:
Large dark brown round-almond eyes with level outer corners and open double eyelids.

Nose signature:
Small straight nose with a low gentle bridge and a neat rounded tip.

Mouth signature:
Small soft rose-pink lips with a shallow cupid bow and an even lower lip.

Skin signature:
Fair neutral skin with a clean luminous finish.

Makeup:
Subtle peach eye shading with a light pink cheek flush and a soft rose lip finish.

Body:
Balanced shoulders.

Permanent identity anchors:
Compact oval face with gently rounded cheeks, large level dark-brown round-almond eyes, small low-bridge nose with a neat rounded tip, small soft rose-pink lips with an even lower lip.

Hair:
Short glossy black jaw-length rounded bob with a soft center part, airy separated fringe and polished inward-curved ends.

Photographic direction:
Photorealistic editorial portrait, clean sports editorial photographic realism, coherent facial identity, realistic technical jersey and athletic trim construction.
```

## 全身角色照
```text
Image Type:
Create a photorealistic character reference portrait in a single 9:16 vertical image.

Subject:
Character Profile Card:
18_Natsuki.

A 20-year-old adult East Asian woman.

Facial geometry:
Soft compact oval face, gently rounded cheeks, a smooth tapered jaw and a neat rounded chin.

Eye signature:
Large dark brown round-almond eyes with level outer corners and open double eyelids.

Nose signature:
Small straight nose with a low gentle bridge and a neat rounded tip.

Mouth signature:
Small soft rose-pink lips with a shallow cupid bow and an even lower lip.

Skin signature:
Fair neutral skin with a clean luminous finish.

Makeup:
Subtle peach eye shading with a light pink cheek flush and a soft rose lip finish.

Body:
Petite athletic proportions with balanced shoulders, a narrow waist and toned legs.

Permanent identity anchors:
Compact oval face with gently rounded cheeks, large level dark-brown round-almond eyes, small low-bridge nose with a neat rounded tip, small soft rose-pink lips with an even lower lip.

Hair:
Short glossy black jaw-length rounded bob with a soft center part, airy separated fringe and polished inward-curved ends.

Lighting:
Clean even lighting with clear facial, body, fabric, and footwear readability.

Camera Look:
Full-body view of the subject standing naturally, centered vertical framing, complete figure visible from head to toe, both hands and both feet completely visible, comfortable space above the hair and below the shoes, natural body proportions, no crop, no hidden limbs, clean realistic character-reference photography, clear facial and garment detail, no visible text.
```

---

## Structured Scheme
* **Style:** Create a photorealistic editorial portrait (寫實攝影), none (全無)
* **Character:** one 20-year-old adult woman (1 位),  (全無), a 20-year-old adult East Asian woman with a soft compact oval face, gently rounded cheeks, a smooth tapered jaw and a neat rounded chin, large dark brown round-almond eyes with level outer corners and open double eyelids, a small straight nose with a low gentle bridge and neat rounded tip, small soft rose-pink lips with an even lower lip, fair neutral skin with a clean luminous finish, subtle peach eye shading and a light pink cheek flush, petite athletic proportions with balanced shoulders, a narrow waist and toned legs, short glossy black jaw-length rounded bob with a soft center part and airy separated fringe, signature outfit locked as a navy racerback athletic crop tank with white piping, matching navy athletic shorts with white trim, and white lace-up athletic sneakers, clean locker-room sports editorial photographic realism (18_Natsuki), none (全無), none (全無), none (全無), none (全無), none (全無), none (全無), none (全無),  (全無), none (全無), none (全無), none (全無), none (全無), none (全無), none (全無)
* **Wardrobe:** no nose piercing (全無), no lip piercing (全無), none (全無), none (全無), none (全無), none (全無), none (全無), none (全無), no added top pattern, clean solid-color surface styling (全無), no outerwear, uncluttered silhouette (全無), none (全無), no legwear, bare legs, clean leg styling (全無), no explicit shoe styling, footwear unspecified (全無), none (全無), none (全無),  (全無), none (全無),  (全無), none (全無), no head accessories, clean head styling (全無), none (全無), no eyewear, clean face styling (全無), no specified eyewear frame color (全無), no earrings, clean ear styling (全無), no neck accessories, open neckline styling (全無),  (全無), none (全無),  (全無), none (全無), none (全無), none (全無), no waist accessories, clean waist styling (全無),  (全無), none (全無),  (全無), none (全無), none (全無), none (全無), no waist accessories, clean waist styling (全無), no waist accessories, clean waist styling (全無)
* **Location:**  (全無), none (全無), none (全無), photographer-shot fixed set portrait, subject arranged within the selected set, fixed composition remains readable, face and wardrobe generally clear where framing allows (攝影師拍攝), let the image model choose a natural body attitude and expression that fits the selected fixed set position and capture mode (模型自然發揮), none (全無)
* **Framing:** none (全無), none (全無), none (全無), none (全無)
* **Lighting:** none (全無), none (全無)
* **Camera & Film:** none (全無), none (全無)
