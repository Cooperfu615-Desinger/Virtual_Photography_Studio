<!-- VPStudio PAGE1 Snapshot: {"version":1,"source":"page1","selection":{"captureMode":"standard","observationCapture":null,"subjectCount":"1","specialSubjectId":"none","characterProfileId":"character-miku","characterCardHairVariantId":"default","characterCardEyewearMode":"default","characterCardWardrobeMode":"full-default","characterCardWardrobeLayerIds":[],"characterCardPromptOverride":"","aspectRatio":"none","mjVersionId":"v8-2","mjAspectRatio":"page1","mjRawMode":"raw","mjStylize":25,"mjChaos":0,"mjWeirdness":0,"mjResolution":"sd","imageTypePresetId":"photorealistic-photo","styleId":"style-none","cameraSystemId":"","sceneAttributeId":"none","locationId":"locations:攝影棚與背景-studio-sets:全無:0","importedWorldSceneMode":"none","importedWorldSceneLabel":"","importedWorldSceneArchitectureText":"","zImageVisibleTextEnabled":false,"zImageVisibleTextContent":"","zImageVisibleTextLanguage":"traditional-chinese","zImageVisibleTextPlacement":"background-storefront-sign","fixedCompositionSetId":"none","fixedSetPositionId":"none","fixedSetBackgroundStateId":"none","fixedSetCaptureModeId":"photographer-shot","fixedSetPerformanceStateId":"model-natural","framingId":"camera:景別構圖-framing:全無:0","angleId":"camera:相機視角-angle:全無:0","orbitId":"camera:拍攝方位-orbit-angle:全無:0","lyingCameraId":"none","captureStyleId":"standard","lensId":"camera:鏡頭焦段-focal-length:全無:0","apertureId":"camera:光圈-景深-aperture-depth-of-field:全無:0","shutterId":"camera:快門-動態殘影-shutter-motion-blur:全無:0","opticalEffectId":"camera:光學效果-optical-effects:全無:0","lightingId":"camera:環境光條件-ambient-light-conditions:全無:0","lightDirectionId":"camera:光線表現-light-style:全無:0","filmId":"camera:底片與相機模擬-camera-film-simulation:全無:0","bodyTypeId":"character:體態-body-type:全無:6","bodyTypeAId":"character:體態-body-type:全無:6","bodyTypeBId":"character:體態-body-type:全無:6","facialFeaturesId":"","facialFeaturesAId":"","facialFeaturesBId":"","skinDetailsId":"","skinDetailsAId":"","skinDetailsBId":"","hairstyleId":"","hairstyleAId":"","hairstyleBId":"","hairStylingStateId":"character:髮絲整理狀態-hair-styling-state:全無:4","hairStylingStateAId":"character:髮絲整理狀態-hair-styling-state:全無:4","hairStylingStateBId":"character:髮絲整理狀態-hair-styling-state:全無:4","hairColorId":"","hairColorAId":"","hairColorBId":"","duoInteractionId":"","duoPoseId":"","duoPoseBaseId":"","duoExpressionId":"","expressionId":"","expressionAId":"","expressionBId":"","poseId":"","specialActionId":"","actionPoseCardId":"","poseBaseId":"none","specifiedActionId":"none","specifiedActionSceneRestore":null,"poseOrientationId":"none","poseArrangementId":"none","poseHandId":"none","posePropId":"none","poseHeadId":"none","poseAnchorId":"none","gestureId":"none","propId":"none","headPostureId":"none","gazeId":"none","specialOutfitId":"","specialOutfitAId":"","specialOutfitBId":"","completeLookPaletteId":"none","completeLookPaletteAId":"none","completeLookPaletteBId":"none","outfitPresetId":"","outfitPresetColorId":"","outfitPresetAId":"","outfitPresetAColorId":"","outfitPresetBId":"","outfitPresetBColorId":"","outfitPresetPrimaryColorId":"","outfitPresetContrastColorId":"","outfitPresetLockedPaletteId":"","outfitPresetAPrimaryColorId":"","outfitPresetAContrastColorId":"","outfitPresetALockedPaletteId":"","outfitPresetBPrimaryColorId":"","outfitPresetBContrastColorId":"","outfitPresetBLockedPaletteId":"","topId":"","topAId":"","topBId":"","topFitId":"","topFitAId":"","topFitBId":"","topStylingId":"","topStylingAId":"","topStylingBId":"","topBottomPaletteId":"none","topBottomPaletteAId":"none","topBottomPaletteBId":"none","topColorId":"","topAColorId":"","topBColorId":"","topPatternId":"","topAPatternId":"","topBPatternId":"","dressId":"","dressAId":"","dressBId":"","dressColorId":"","dressAColorId":"","dressBColorId":"","pantsId":"","pantsAId":"","pantsBId":"","skirtId":"","skirtAId":"","skirtBId":"","bottomFitId":"","bottomFitAId":"","bottomFitBId":"","bottomRiseId":"","bottomRiseAId":"","bottomRiseBId":"","bottomColorId":"","bottomAColorId":"","bottomBColorId":"","bottomPatternId":"","bottomAPatternId":"","bottomBPatternId":"","outerwearId":"","outerwearFitId":"","outerwearColorId":"","outerwearPatternId":"","outerwearOpeningId":"wardrobe:外套開合-outerwear-opening:全無:4","outerwearStylingId":"","legwearId":"","legwearColorId":"","shoesId":"","shoesColorId":"","outerwearAId":"","outerwearAFitId":"","outerwearAColorId":"","outerwearAPatternId":"","outerwearAOpeningId":"wardrobe:外套開合-outerwear-opening:全無:4","outerwearAStylingId":"","legwearAId":"","legwearAColorId":"","shoesAId":"","shoesAColorId":"","outerwearBId":"","outerwearBFitId":"","outerwearBColorId":"","outerwearBPatternId":"","outerwearBOpeningId":"wardrobe:外套開合-outerwear-opening:全無:4","outerwearBStylingId":"","legwearBId":"","legwearBColorId":"","shoesBId":"","shoesBColorId":"","headphonesId":"wardrobe:headphones:none","headphonesColorId":"none","faceCoveringId":"wardrobe:faceCovering:none","faceCoveringColorId":"none","headAccessoryId":"","headAccessoryColorId":"none","eyewearId":"","eyewearColorId":"","eyewearPlacementId":"wardrobe:眼鏡配戴方式-eyewear-placement:全無:2","earringsId":"","nosePiercingId":"wardrobe:鼻部穿孔-nose-piercings:全無:0","lipPiercingId":"wardrobe:唇部穿孔-lip-piercings:全無:0","neckAccessoryId":"","waistAccessoryId":"wardrobe:腰部配件-waist-accessories:全無:0","headphonesAId":"wardrobe:headphones:none","headphonesAColorId":"none","faceCoveringAId":"wardrobe:faceCovering:none","faceCoveringAColorId":"none","headAccessoryAId":"","headAccessoryAColorId":"none","eyewearAId":"","eyewearAColorId":"","eyewearAPlacementId":"wardrobe:眼鏡配戴方式-eyewear-placement:全無:2","earringsAId":"","neckAccessoryAId":"","waistAccessoryAId":"wardrobe:腰部配件-waist-accessories:全無:0","headphonesBId":"wardrobe:headphones:none","headphonesBColorId":"none","faceCoveringBId":"wardrobe:faceCovering:none","faceCoveringBColorId":"none","headAccessoryBId":"","headAccessoryBColorId":"none","eyewearBId":"","eyewearBColorId":"","eyewearBPlacementId":"wardrobe:眼鏡配戴方式-eyewear-placement:全無:2","earringsBId":"","neckAccessoryBId":"","waistAccessoryBId":"wardrobe:腰部配件-waist-accessories:全無:0"},"outputs":{"grokPrompt":"Image Type:\nCreate a photorealistic editorial portrait.\n\nSubject:\nCharacter Profile Card:\n36_Miku.\n\nA 20-year-old adult East Asian woman.\n\nFacial geometry:\nCompact soft oval face, gently rounded cheeks, a narrow smooth jaw and a neat rounded chin.\n\nEye signature:\nLarge dark brown round-almond eyes set slightly wide with level outer corners, open double eyelids and soft lower-lid fullness.\n\nNose signature:\nSmall straight nose with a low gentle bridge and a tidy rounded tip.\n\nMouth signature:\nSmall rose-red lips with a shallow cupid bow and a fuller lower lip.\n\nSkin signature:\nFair neutral skin with a clean luminous finish.\n\nMakeup:\nFine brown-black upper-lash definition with restrained pink cheek color and a rose-red lip finish.\n\nBody:\nPetite balanced proportions with narrow shoulders, a defined waist and softly toned legs.\n\nPermanent identity anchors:\nCompact soft oval face with rounded cheeks, large wide-set dark-brown round-almond eyes, small low-bridge rounded-tip nose, small rose-red lips with a fuller lower lip.\n\nHair:\nLong natural black hair gathered into a high braided looped bun with curled ribbon-like loops, airy eyebrow-skimming bangs and long curled face-framing tendrils.\n\nOutfit:\nNavy oversized V-neck cardigan over a crisp white collared shirt, navy pleated mini skirt, navy ankle socks, black leather penny loafers.\n\nAccessories:\nNavy striped bow tie and a black nylon school backpack with a small plush teddy-bear charm.\n\nPhotographic direction:\nPhotorealistic editorial portrait, bright photographic realism, coherent facial identity, realistic knitwear, cotton shirting, pleated fabric and leather construction.","midjourneyPrompt":"Photorealistic editorial portrait. A 20-year-old adult East Asian woman, compact soft oval face with rounded cheeks, large wide-set dark-brown round-almond eyes, small low-bridge rounded-tip nose, small rose-red lips with a fuller lower lip, fair neutral skin with a clean luminous finish, fine brown-black upper-lash definition with restrained pink cheek color and a rose-red lip finish, long natural black hair gathered into a high braided looped bun with curled ribbon-like loops, airy eyebrow-skimming bangs and long curled face-framing tendrils.\n\nShe wears a v-neck cardigan, a collared shirt, a pleated mini skirt, ankle socks, leather penny loafers, a bow tie and a school backpack. --v 8.2 --ar 2:3 --raw --s 25 --c 0 --w 0 --sd","zImagePrompt":"Photorealistic editorial portrait.\n\nA 20-year-old adult East Asian woman, compact soft oval face with rounded cheeks, large wide-set dark-brown round-almond eyes, small low-bridge rounded-tip nose, small rose-red lips with a fuller lower lip, fair neutral skin with a clean luminous finish, petite balanced proportions with narrow shoulders, a defined waist and softly toned legs, long natural black hair gathered into a high braided looped bun with curled ribbon-like loops, airy eyebrow-skimming bangs and long curled face-framing tendrils.\n\nShe wears navy oversized V-neck cardigan over a crisp white collared shirt, navy pleated mini skirt, navy ankle socks, black leather penny loafers, navy striped bow tie and a black nylon school backpack with a small plush teddy-bear charm.","nanoBananaPrompt":"Create a photorealistic editorial portrait.\n\nThe subject is a 20-year-old adult East Asian woman. She has a compact soft oval face, gently rounded cheeks, a narrow smooth jaw and a neat rounded chin. Her eyes are large dark brown round-almond eyes set slightly wide with level outer corners, open double eyelids and soft lower-lid fullness. She has a small straight nose with a low gentle bridge and a tidy rounded tip. Her lips are small rose-red lips with a shallow cupid bow and a fuller lower lip. Her complexion shows fair neutral skin with a clean luminous finish. Her makeup uses fine brown-black upper-lash definition with restrained pink cheek color and a rose-red lip finish. Her figure has petite balanced proportions with narrow shoulders, a defined waist and softly toned legs. Her defining features are compact soft oval face with rounded cheeks, large wide-set dark-brown round-almond eyes, small low-bridge rounded-tip nose, small rose-red lips with a fuller lower lip. Her hair is long natural black hair gathered into a high braided looped bun with curled ribbon-like loops, airy eyebrow-skimming bangs and long curled face-framing tendrils. Navy striped bow tie and a black nylon school backpack with a small plush teddy-bear charm. Photorealistic editorial portrait, bright photographic realism, coherent facial identity, realistic knitwear, cotton shirting, pleated fabric and leather construction.\n\nShe wears navy oversized V-neck cardigan over a crisp white collared shirt, navy pleated mini skirt, navy ankle socks, black leather penny loafers.","extraPrompts":[{"id":"chest-up-portrait","label":"胸上特寫照","text":"Image Type:\nCreate a photorealistic editorial portrait.\n\nComposition:\nVertical portrait composition at a 4:5 aspect ratio, chest-up portrait.\n\nSubject:\nCharacter Profile Card:\n36_Miku.\n\nA 20-year-old adult East Asian woman.\n\nFacial geometry:\nCompact soft oval face, gently rounded cheeks, a narrow smooth jaw and a neat rounded chin.\n\nEye signature:\nLarge dark brown round-almond eyes set slightly wide with level outer corners, open double eyelids and soft lower-lid fullness.\n\nNose signature:\nSmall straight nose with a low gentle bridge and a tidy rounded tip.\n\nMouth signature:\nSmall rose-red lips with a shallow cupid bow and a fuller lower lip.\n\nSkin signature:\nFair neutral skin with a clean luminous finish.\n\nMakeup:\nFine brown-black upper-lash definition with restrained pink cheek color and a rose-red lip finish.\n\nBody:\nNarrow shoulders.\n\nPermanent identity anchors:\nCompact soft oval face with rounded cheeks, large wide-set dark-brown round-almond eyes, small low-bridge rounded-tip nose, small rose-red lips with a fuller lower lip.\n\nHair:\nLong natural black hair gathered into a high braided looped bun with curled ribbon-like loops, airy eyebrow-skimming bangs and long curled face-framing tendrils.\n\nPhotographic direction:\nPhotorealistic editorial portrait, bright photographic realism, coherent facial identity, realistic knitwear, cotton shirting, pleated fabric and leather construction.\n\nWardrobe:\nShe wears navy oversized V-neck cardigan over a crisp white collared shirt."},{"id":"full-body-character","label":"全身角色照","text":"Image Type:\nCreate a photorealistic character reference portrait in a single 9:16 vertical image.\n\nSubject:\nCharacter Profile Card:\n36_Miku.\n\nA 20-year-old adult East Asian woman.\n\nFacial geometry:\nCompact soft oval face, gently rounded cheeks, a narrow smooth jaw and a neat rounded chin.\n\nEye signature:\nLarge dark brown round-almond eyes set slightly wide with level outer corners, open double eyelids and soft lower-lid fullness.\n\nNose signature:\nSmall straight nose with a low gentle bridge and a tidy rounded tip.\n\nMouth signature:\nSmall rose-red lips with a shallow cupid bow and a fuller lower lip.\n\nSkin signature:\nFair neutral skin with a clean luminous finish.\n\nMakeup:\nFine brown-black upper-lash definition with restrained pink cheek color and a rose-red lip finish.\n\nBody:\nPetite balanced proportions with narrow shoulders, a defined waist and softly toned legs.\n\nPermanent identity anchors:\nCompact soft oval face with rounded cheeks, large wide-set dark-brown round-almond eyes, small low-bridge rounded-tip nose, small rose-red lips with a fuller lower lip.\n\nHair:\nLong natural black hair gathered into a high braided looped bun with curled ribbon-like loops, airy eyebrow-skimming bangs and long curled face-framing tendrils.\n\nAccessories:\nNavy striped bow tie and a black nylon school backpack with a small plush teddy-bear charm.\n\nWardrobe:\nShe wears navy oversized V-neck cardigan over a crisp white collared shirt, navy pleated mini skirt, navy ankle socks, black leather penny loafers.\n\nLighting:\nClean even lighting with clear facial, body, fabric, and footwear readability.\n\nCamera Look:\nFull-body view of the subject standing naturally, centered vertical framing, complete figure visible from head to toe, both hands and both feet completely visible, comfortable space above the hair and below the shoes, natural body proportions, no crop, no hidden limbs, clean realistic character-reference photography, clear facial and garment detail, no visible text."}]},"promptLabels":null} -->
<!-- VPStudio Optional Silence: {"sceneAttributeId":"none","bodyTypeId":"character:體態-body-type:全無:6","bodyTypeAId":"character:體態-body-type:全無:6","bodyTypeBId":"character:體態-body-type:全無:6","hairStylingStateId":"character:髮絲整理狀態-hair-styling-state:全無:4","hairStylingStateAId":"character:髮絲整理狀態-hair-styling-state:全無:4","hairStylingStateBId":"character:髮絲整理狀態-hair-styling-state:全無:4","outerwearOpeningId":"wardrobe:外套開合-outerwear-opening:全無:4","outerwearAOpeningId":"wardrobe:外套開合-outerwear-opening:全無:4","outerwearBOpeningId":"wardrobe:外套開合-outerwear-opening:全無:4","eyewearPlacementId":"wardrobe:眼鏡配戴方式-eyewear-placement:全無:2","eyewearAPlacementId":"wardrobe:眼鏡配戴方式-eyewear-placement:全無:2","eyewearBPlacementId":"wardrobe:眼鏡配戴方式-eyewear-placement:全無:2"} -->
# Generated Prompt - 10/31/2026, 8:00:00 AM
**Source:** Prompt 工作台
**Summary:** 風格：寫實攝影 | 人物：36_Miku / 36_Miku 角色卡 | 服裝：- | 場景：- | 鏡頭：- | 光影：-

## AI Prompt
```text
Photorealistic editorial portrait. A 20-year-old adult East Asian woman, compact soft oval face with rounded cheeks, large wide-set dark-brown round-almond eyes, small low-bridge rounded-tip nose, small rose-red lips with a fuller lower lip, fair neutral skin with a clean luminous finish, fine brown-black upper-lash definition with restrained pink cheek color and a rose-red lip finish, long natural black hair gathered into a high braided looped bun with curled ribbon-like loops, airy eyebrow-skimming bangs and long curled face-framing tendrils.

She wears a v-neck cardigan, a collared shirt, a pleated mini skirt, ankle socks, leather penny loafers, a bow tie and a school backpack. --v 8.2 --ar 2:3 --raw --s 25 --c 0 --w 0 --sd
```

## Gpt
```text
Image Type:
Create a photorealistic editorial portrait.

Subject:
Character Profile Card:
36_Miku.

A 20-year-old adult East Asian woman.

Facial geometry:
Compact soft oval face, gently rounded cheeks, a narrow smooth jaw and a neat rounded chin.

Eye signature:
Large dark brown round-almond eyes set slightly wide with level outer corners, open double eyelids and soft lower-lid fullness.

Nose signature:
Small straight nose with a low gentle bridge and a tidy rounded tip.

Mouth signature:
Small rose-red lips with a shallow cupid bow and a fuller lower lip.

Skin signature:
Fair neutral skin with a clean luminous finish.

Makeup:
Fine brown-black upper-lash definition with restrained pink cheek color and a rose-red lip finish.

Body:
Petite balanced proportions with narrow shoulders, a defined waist and softly toned legs.

Permanent identity anchors:
Compact soft oval face with rounded cheeks, large wide-set dark-brown round-almond eyes, small low-bridge rounded-tip nose, small rose-red lips with a fuller lower lip.

Hair:
Long natural black hair gathered into a high braided looped bun with curled ribbon-like loops, airy eyebrow-skimming bangs and long curled face-framing tendrils.

Outfit:
Navy oversized V-neck cardigan over a crisp white collared shirt, navy pleated mini skirt, navy ankle socks, black leather penny loafers.

Accessories:
Navy striped bow tie and a black nylon school backpack with a small plush teddy-bear charm.

Photographic direction:
Photorealistic editorial portrait, bright photographic realism, coherent facial identity, realistic knitwear, cotton shirting, pleated fabric and leather construction.
```

## Z-Image
```text
Photorealistic editorial portrait.

A 20-year-old adult East Asian woman, compact soft oval face with rounded cheeks, large wide-set dark-brown round-almond eyes, small low-bridge rounded-tip nose, small rose-red lips with a fuller lower lip, fair neutral skin with a clean luminous finish, petite balanced proportions with narrow shoulders, a defined waist and softly toned legs, long natural black hair gathered into a high braided looped bun with curled ribbon-like loops, airy eyebrow-skimming bangs and long curled face-framing tendrils.

She wears navy oversized V-neck cardigan over a crisp white collared shirt, navy pleated mini skirt, navy ankle socks, black leather penny loafers, navy striped bow tie and a black nylon school backpack with a small plush teddy-bear charm.
```

## Nano Banana 2.1
```text
Create a photorealistic editorial portrait.

The subject is a 20-year-old adult East Asian woman. She has a compact soft oval face, gently rounded cheeks, a narrow smooth jaw and a neat rounded chin. Her eyes are large dark brown round-almond eyes set slightly wide with level outer corners, open double eyelids and soft lower-lid fullness. She has a small straight nose with a low gentle bridge and a tidy rounded tip. Her lips are small rose-red lips with a shallow cupid bow and a fuller lower lip. Her complexion shows fair neutral skin with a clean luminous finish. Her makeup uses fine brown-black upper-lash definition with restrained pink cheek color and a rose-red lip finish. Her figure has petite balanced proportions with narrow shoulders, a defined waist and softly toned legs. Her defining features are compact soft oval face with rounded cheeks, large wide-set dark-brown round-almond eyes, small low-bridge rounded-tip nose, small rose-red lips with a fuller lower lip. Her hair is long natural black hair gathered into a high braided looped bun with curled ribbon-like loops, airy eyebrow-skimming bangs and long curled face-framing tendrils. Navy striped bow tie and a black nylon school backpack with a small plush teddy-bear charm. Photorealistic editorial portrait, bright photographic realism, coherent facial identity, realistic knitwear, cotton shirting, pleated fabric and leather construction.

She wears navy oversized V-neck cardigan over a crisp white collared shirt, navy pleated mini skirt, navy ankle socks, black leather penny loafers.
```

## 胸上特寫照
```text
Image Type:
Create a photorealistic editorial portrait.

Composition:
Vertical portrait composition at a 4:5 aspect ratio, chest-up portrait.

Subject:
Character Profile Card:
36_Miku.

A 20-year-old adult East Asian woman.

Facial geometry:
Compact soft oval face, gently rounded cheeks, a narrow smooth jaw and a neat rounded chin.

Eye signature:
Large dark brown round-almond eyes set slightly wide with level outer corners, open double eyelids and soft lower-lid fullness.

Nose signature:
Small straight nose with a low gentle bridge and a tidy rounded tip.

Mouth signature:
Small rose-red lips with a shallow cupid bow and a fuller lower lip.

Skin signature:
Fair neutral skin with a clean luminous finish.

Makeup:
Fine brown-black upper-lash definition with restrained pink cheek color and a rose-red lip finish.

Body:
Narrow shoulders.

Permanent identity anchors:
Compact soft oval face with rounded cheeks, large wide-set dark-brown round-almond eyes, small low-bridge rounded-tip nose, small rose-red lips with a fuller lower lip.

Hair:
Long natural black hair gathered into a high braided looped bun with curled ribbon-like loops, airy eyebrow-skimming bangs and long curled face-framing tendrils.

Photographic direction:
Photorealistic editorial portrait, bright photographic realism, coherent facial identity, realistic knitwear, cotton shirting, pleated fabric and leather construction.

Wardrobe:
She wears navy oversized V-neck cardigan over a crisp white collared shirt.
```

## 全身角色照
```text
Image Type:
Create a photorealistic character reference portrait in a single 9:16 vertical image.

Subject:
Character Profile Card:
36_Miku.

A 20-year-old adult East Asian woman.

Facial geometry:
Compact soft oval face, gently rounded cheeks, a narrow smooth jaw and a neat rounded chin.

Eye signature:
Large dark brown round-almond eyes set slightly wide with level outer corners, open double eyelids and soft lower-lid fullness.

Nose signature:
Small straight nose with a low gentle bridge and a tidy rounded tip.

Mouth signature:
Small rose-red lips with a shallow cupid bow and a fuller lower lip.

Skin signature:
Fair neutral skin with a clean luminous finish.

Makeup:
Fine brown-black upper-lash definition with restrained pink cheek color and a rose-red lip finish.

Body:
Petite balanced proportions with narrow shoulders, a defined waist and softly toned legs.

Permanent identity anchors:
Compact soft oval face with rounded cheeks, large wide-set dark-brown round-almond eyes, small low-bridge rounded-tip nose, small rose-red lips with a fuller lower lip.

Hair:
Long natural black hair gathered into a high braided looped bun with curled ribbon-like loops, airy eyebrow-skimming bangs and long curled face-framing tendrils.

Accessories:
Navy striped bow tie and a black nylon school backpack with a small plush teddy-bear charm.

Wardrobe:
She wears navy oversized V-neck cardigan over a crisp white collared shirt, navy pleated mini skirt, navy ankle socks, black leather penny loafers.

Lighting:
Clean even lighting with clear facial, body, fabric, and footwear readability.

Camera Look:
Full-body view of the subject standing naturally, centered vertical framing, complete figure visible from head to toe, both hands and both feet completely visible, comfortable space above the hair and below the shoes, natural body proportions, no crop, no hidden limbs, clean realistic character-reference photography, clear facial and garment detail, no visible text.
```

---

## Structured Scheme
* **Style:** Create a photorealistic editorial portrait (寫實攝影), none (全無)
* **Character:** one 20-year-old adult woman (1 位),  (全無), a 20-year-old adult East Asian woman with a compact soft oval face, gently rounded cheeks, a narrow smooth jaw and a neat rounded chin, large dark brown round-almond eyes set slightly wide with level outer corners, open double eyelids and soft lower-lid fullness, a small straight nose with a low gentle bridge and a tidy rounded tip, small rose-red lips with a shallow cupid bow and a fuller lower lip, fair neutral skin with a clean luminous finish, fine brown-black upper-lash definition and restrained pink cheek color, petite balanced proportions with narrow shoulders, a defined waist and softly toned legs, long natural black hair gathered into a high braided looped bun with curled ribbon-like loops, airy eyebrow-skimming bangs and long curled face-framing tendrils, signature outfit locked as a navy oversized V-neck cardigan over a crisp white collared shirt, a navy striped bow tie, a navy pleated mini skirt, navy ankle socks, and black leather penny loafers, black nylon school backpack with a small plush teddy-bear charm, bright commuter-train photographic realism (36_Miku), none (全無), none (全無), none (全無), none (全無), none (全無), none (全無), none (全無),  (全無), none (全無), none (全無), none (全無), none (全無), none (全無), none (全無)
* **Wardrobe:** no nose piercing (全無), no lip piercing (全無), none (全無), none (全無), none (全無), none (全無), none (全無), none (全無), none (全無), none (全無), none (全無),  (全無), none (全無),  (全無), none (全無), none (全無),  (全無), none (全無),  (全無), none (全無), none (全無), none (全無), no waist accessories, clean waist styling (全無),  (全無), none (全無),  (全無), none (全無), none (全無), none (全無), no waist accessories, clean waist styling (全無), no waist accessories, clean waist styling (全無)
* **Location:**  (全無), none (全無), none (全無), photographer-shot fixed set portrait, subject arranged within the selected set, fixed composition remains readable, face and wardrobe generally clear where framing allows (攝影師拍攝), let the image model choose a natural body attitude and expression that fits the selected fixed set position and capture mode (模型自然發揮), none (全無)
* **Framing:** none (全無), none (全無), none (全無), none (全無)
* **Lighting:** none (全無), none (全無)
* **Camera & Film:** none (全無), none (全無)
